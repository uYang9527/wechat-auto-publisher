# Changelog

## 2026-11-15
- Initial skill creation based on wechat-ops-assistant workflow with full API draft push support.
- Fused core capabilities: 热点雷达选题、系统化去 AI 味门禁、多主题排版系统。
- Expanded HTML themes to 8 sets and strengthened AI flavor detection.
- Added README.md for GitHub distribution.
- **Major optimization (addressing expert review)**:
  - 热点雷达优先使用用户提供的实时数据，未提供时明确标注模拟限制。
  - 去AI味门禁升级为强制清单式逐条核对（已规避/仍存在）。
  - 增加会话内偏好记忆与关键节点显式确认。
  - 文风规范明确支持用户自定义优先（适配多种风格）。
  - 配图增加降级方案与外部工具指引。
  - API 失败时强化手动 checklist 输出。
