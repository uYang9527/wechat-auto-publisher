# 微信公众号 HTML 排版模板与多主题系统

## 使用说明

- 输出完整可复制的 HTML 片段，可直接粘贴到微信公众号后台「编辑器」的「源代码」或兼容编辑器中。
- 所有样式使用内联 style，确保微信兼容性。
- 避免使用微信不支持的 CSS 属性（position: absolute、部分 flex/grid 高级用法、动画等需谨慎）。
- 默认主题为「简约」。用户可指定主题，或由内容风格自动推荐。

## 支持主题列表

| 主题 | 适用场景 | 主色 | 强调色 | 背景色 |
|------|----------|------|--------|--------|
| 简约 | 通用、日常 | #1a1a1a | #07c160 | #f7f7f7 |
| 商务 | 职场、商业、分析 | #1a365d | #2b6cb0 | #edf2f7 |
| 温暖 | 生活、情感、故事 | #5c3317 | #dd6b20 | #fffaf0 |
| 科技 | 数码、AI、产品 | #1a202c | #3182ce | #ebf8ff |
| 国潮 | 文化、传统、品牌 | #742a2a | #c53030 | #fff5f5 |
| 学术 | 深度分析、研究 | #2d3748 | #4a5568 | #f7fafc |
| 杂志 | 资讯、报道、观点 | #1a1a1a | #e53e3e | #fff5f5 |
| 极简黑白 | 技术、工程、极简 | #000000 | #333333 | #fafafa |

输出时根据选定主题替换对应颜色变量。

## 基础结构

```html
<section style="max-width: 100%; margin: 0 auto; padding: 0 16px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; color: #333; line-height: 1.75; font-size: 16px;">
  <!-- 内容组件 -->
</section>
```

## 结构化组件

### 主标题
```html
<h1 style="font-size: 22px; font-weight: 600; color: [主色]; margin: 24px 0 16px; line-height: 1.4; text-align: center;">标题文字</h1>
```

### 副标题 / 引言
```html
<p style="font-size: 15px; color: #666; margin: 0 0 24px; padding: 12px 16px; background: [背景色]; border-left: 4px solid [强调色]; line-height: 1.6;">引言或副标题内容</p>
```

### 正文段落
```html
<p style="margin: 0 0 18px; text-align: justify; font-size: 16px; color: #333;">正文内容</p>
```

### 小标题
```html
<h2 style="font-size: 18px; font-weight: 600; color: [主色]; margin: 28px 0 12px; padding-bottom: 8px; border-bottom: 2px solid [强调色];">小标题</h2>
```

### 引用块
```html
<blockquote style="margin: 20px 0; padding: 12px 16px; background: [背景色]; border-left: 4px solid [强调色]; color: #555; font-size: 15px;">引用内容</blockquote>
```

### 分割线
```html
<hr style="border: none; border-top: 1px solid #eee; margin: 28px 0;">
```

### 重点卡片
```html
<div style="margin: 20px 0; padding: 16px; background: [背景色]; border-radius: 8px; border: 1px solid [强调色];">
  <p style="margin: 0; font-size: 15px; color: [主色]; line-height: 1.6;">重点内容</p>
</div>
```

### 结尾引导
```html
<p style="margin: 32px 0 16px; text-align: center; font-size: 15px; color: #666;">如果觉得有帮助，欢迎点赞、在看或转发给需要的朋友。</p>
```

## 使用建议

- 同一篇文章内保持主题一致性。
- 重点卡片和引用块用于打破节奏、突出关键信息。
- 长文适当增加小标题与分割线，提升可读性。
- 颜色严格按主题表替换，避免混用。
